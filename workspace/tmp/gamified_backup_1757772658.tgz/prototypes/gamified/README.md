# Gamified Orchestrator (Prototype)

This directory contains prompt-first assets for the Codex‑exec orchestrator.
If this folder was recreated automatically, minimal defaults were written.

Contents:
- rules/score_v1.json — default scoring weights and plateau config
- docs/prompt_multiplication_with_tasks.md — ready-to-run POC prompt
- docs/tasks/001_Smokes.md/README.md — Smokes + Contracts spec
